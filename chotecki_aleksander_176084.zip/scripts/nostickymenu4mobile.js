if (window.matchMedia("(max-width:800px)").matches) 
{
    document.write('<style>.stickymenu{position:static!important;}</style>');
}